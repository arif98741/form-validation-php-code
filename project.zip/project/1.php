
<?php
$x = 6;
$y = 7;
$result = $x+$y;
echo "$result";

 ?>
