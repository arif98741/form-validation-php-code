<form method="post"  action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
			<table>
			<p style="color:red;">* required fields</p>
				<tr>
					<td>Name</td>
					<td><input type="text" name="name" required="1">*<?php echo $errname; ?></td>

				</tr>
				<tr>
					<td>E-mail</td>
					<td><input type="text" name="email" required="2">*<?php echo $erremail; ?></td>

				</tr>
				<tr>
					<td>Website</td>
					<td><input type="text" name="website" required="3">*<?php echo $errweb; ?></td>

				</tr>
				<tr>
					<td>Comment</td>
					<td><textarea name="comment" rows="5" cols="40" required="4"></textarea></td>

				</tr>
				<tr>
					<td>Gender</td>
					<td>
						<input type="radio" name="gender" value="female"/>Female
						<input type="radio" name="gender" value="male"/>Male*<?php echo $errgender ?>
					</td>

				</tr>
				<tr>
					<td></td>
					<td>
						<input type="submit" name="submit" value="submit"/>
					</td>

				</tr>


			</table>
			</form>
			