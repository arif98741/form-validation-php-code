<?php
$fonts = "Times New Roman";
$bgcolor = "#444";
$fontcolor = "#EEC966";
$errname = $erremail = $errweb = $errcomment= $errgender= "";



 ?>
<!DOCTYPE html>
<html>
<head>
	<title>PHP array Sorting</title>
	<style type="text/css">
		body{font-family: <?php echo $fonts ?>; background: #E6E6E6;}
		.phpcoding{width: 900px; margin: 0 auto; background: <?php echo "#ddd"?>; min-height:400px; }
		.headeroption, .footeroption{background: <?php echo $bgcolor; ?>; color: <?php echo $fontcolor; ?>; text-align: center; padding: 20px}
		.headeroption h2, .footeroption h2{margin: 0px; font-family: Rockwell;}
		.maincontent{min-height: 400px; padding: 10px}

	</style>
</head>

<body>

	<div class="phpcoding">
		<section class="headeroption">
			<h2><?php echo "Fundamental Training With Live Project"?></h2>

		</section>
		<section class="maincontent">
		
		<br/>
		<hr/>
		<b>PHP Form Validation</i></b> 
		<hr/>
		<script type="text/javascript"></script>
		 <?php include 'form.php'; ?>

			<?php
			$name 		= "";
			$email 		= "";
			$website 	= "";
			$comment 	= "";
			$gender 	= "";

				if ($_SERVER["REQUEST_METHOD"] == "POST") {
					if(empty($_POST['name'])){
						$errname =  "Name is required";

					}
					else
					{
						$name = validate($_POST['name']);
					}



					if(empty($_POST['email'])){
						$erremail =  "Email is requierd";

					}
					else
					{
						$eamil = validate($_POST['email']);
					}



					if(empty($_POST['website'])){
						$errweb =  "Website is requierd";

					}
					else
					{
						$website = validate($_POST['website']);
					}

					if(empty($_POST['gender'])){
						$errgender =  "Website is requierd";

					}
					else
					{
						$gender = validate($_POST['gender']);
					}


					$name 	 	= validate($_POST['name']);
					$email 		= validate($_POST['email']);
					$website	= validate($_POST['website']);
					$comment 	= validate($_POST['comment']);
					$gender 	= validate($_POST['gender']);


					echo "Name: ".$name."<br/>";
					echo "Email: ".$email."<br/>";
					echo "Website: ".$website."<br/>";
					echo "Comment: ".$comment."<br/>";
					echo "Gender: ".$gender."<br/>";

				}

				function validate($data){
					$data = trim($data);
					$data = stripcslashes($data);
					$data = htmlspecialchars($data);
					return $data;
				}
				
				
			 ?>
			 

				 
		  </hr>

		</section>
		
		</span>
		
		<!--array_diff checks difference acording to values in php -->
		<!-- array_diff_assoc checks difference acording to key and value in php-->


		</section>
				<section class="footeroption">
        <p style="margin: 0px">&copy; <?php echo date ("Y")?> Ariful  Islam Personal Blog For Open Discussion </p>
        <h2><?php echo "Mixedbdblog.wordpress.com"?></h2>
        </section>
    </div>

</body>
</html>



<!-- 
<?php include 'header.php'; ?>
<?php include 'maincontent.php'; ?>
<?php require 'footer.php'; ?> -->
		