		<section class="maincontent">
		
		<br/>
		<hr/>
		<b>PHP Form Validation</i></b> 
		<hr/>
		<script type="text/javascript"></script>
		 <?php include 'form.php'; ?>

			<?php
			$name 		= "";
			$email 		= "";
			$website 	= "";
			$comment 	= "";
			$gender 	= "";

			
				if ($_SERVER["REQUEST_METHOD"] == "POST") {
					if(empty($_POST['name'])){
						$errname =  "Name is required";

					}
					else
					{
						$name = validate($_POST['name']);
					}

					if(empty($_POST['email'])){
						$erremail =  "Email is requierd";

					}
					else
					{
						$eamil = validate($_POST['email']);
					}

					if(empty($_POST['website'])){
						$errweb =  "Website is requierd";

					}
					else
					{
						$website = validate($_POST['website']);
					}
					
					if(empty($_POST['gender'])){
						$errgender =  "Website is requierd";

					}
					else
					{
						$gender = validate($_POST['gender']);
					}


					$name 	 	= validate($_POST['name']);
					$email 		= validate($_POST['email']);
					$website	= validate($_POST['website']);
					$comment 	= validate($_POST['comment']);
					$gender 	= validate($_POST['gender']);

					echo "Name: ".$name."<br/>";
					echo "Email: ".$email."<br/>";
					echo "Website: ".$website."<br/>";
					echo "Comment: ".$comment."<br/>";
					echo "Gender: ".$gender."<br/>";

				}

				function validate($data){
					$data = trim($data);
					$data = stripcslashes($data);
					$data = htmlspecialchars($data);
					return $data;
				}
			 ?>
			 

				 
		  </hr>

		</section>
		
		</span>
		
		<!--array_diff checks difference acording to values in php -->
		<!-- array_diff_assoc checks difference acording to key and value in php-->


		</section>