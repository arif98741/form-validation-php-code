<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$database = 'wordpress';
mysql_connect($host,$user, $pass);



?>