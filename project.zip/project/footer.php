		<section class="footeroption">
        <p style="margin: 0px">&copy; <?php echo date ("Y")?> Ariful  Islam Personal Blog For Open Discussion </p>
        <h2><?php echo "Mixedbdblog.wordpress.com"?></h2>
        </section>
    </div>

</body>
</html>