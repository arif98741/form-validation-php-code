<?php
$fonts = "Times New Roman";
$bgcolor = "#444";
$fontcolor = "#EEC966";
$errname = $erremail = $errweb = $errcomment= $errgender= "";



 ?>
<!DOCTYPE html>
<html>
 <?php include 'style.php'; ?>

<body>

    <div class="phpcoding">
        <section class="headeroption">
            <h2><?php echo "Fundamental Training With Live Project"?></h2>

        </section>

        <section class="maincontent">
        
        <br/>
        <hr/>
        <b>PHP Form Validation</i></b> 
        <hr/>
        <script type="text/javascript"></script>
        
            

            <?php
               echo "Today is  ".date("d.m.Y")."<br/>" ;
               echo "Today is  ".date("l")."<br/>" ;
               echo "Default time  is  ".date("h:i:sa")."<br/>" ;

               date_default_timezone_set('Asia/Dhaka')."<br/>"."<br/>";
               echo "Today is  ".date("h:i:sa")."<br/>" ;

               echo date_default_timezone_get('Asia/Dhaka');


            
             ?>
             

                 
          </hr>

        </section>
        
        </span>
        
        <!--array_diff checks difference acording to values in php -->
        <!-- array_diff_assoc checks difference acording to key and value in php-->


        </section>


        
        <?php include 'footer.php'; ?>