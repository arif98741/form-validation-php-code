<?php
$fonts = "Times New Roman";
$bgcolor = "#444";
$fontcolor = "#EEC966";
$errname = $erremail = $errweb = $errcomment= $errgender= "";



 ?>
<!DOCTYPE html>
<html>
<head>
	<title>PHP array Sorting</title>
	<style type="text/css">
		body{font-family: <?php echo $fonts ?>; background: black;}
		.phpcoding{width: 900px; margin: 0 auto; background: <?php echo "#ddd"?>; min-height:400px; }
		.headeroption, .footeroption{background: <?php echo $bgcolor; ?>; color: <?php echo $fontcolor; ?>; text-align: center; padding: 20px}
		.headeroption h2, .footeroption h2{margin: 0px; font-family: Rockwell;}
		.maincontent{min-height: 400px; padding: 10px}

	</style>
</head>

<body>

	<div class="phpcoding">
		<section class="headeroption">
			<h2><?php echo "Fundamental Training With Live Project"?></h2>

		</section>